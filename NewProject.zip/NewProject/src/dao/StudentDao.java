/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import model.*;
/**
 *
 * @author Mwamba
 */
public class StudentDao {
    private String url="jdbc:postgresql://localhost:5432/new_db";
    private String user="postgres";
    private String password="joseph123";

    public StudentDao() {
    }
    
    public String registerStudent(Student studentObj){
        try{
            Connection con =  DriverManager.getConnection(url, user, password);
            Statement st = con.createStatement();
            String sql = "insert into studenttable (student_id,student_name,faculty,department,phone) values ("+studentObj.getId()+",'"+studentObj.getName()+"','"+studentObj.getFaculty()+"','"+studentObj.getDepartment()+"','"+studentObj.getPhone()+"')";
            int rowAffected = st.executeUpdate(sql);
            con.close();
            if (rowAffected>=1){
                return "Data saved successfully";
            
            }else{
                return "Data not saved";
            }
        }catch(Exception ex){
            ex.printStackTrace();
            return "Server error";
        }
    
    }
    public String updateStudent(Student studentObj){
        try{
            Connection con= DriverManager.getConnection(url, user, password);
            String sql = "update studenttable set student_name=?,faculty=?,department=?,phone=? where student_id=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(5, studentObj.getId());
            pst.setString(1, studentObj.getName());
            pst.setString(2, studentObj.getFaculty());
            pst.setString(3, studentObj.getDepartment());
            pst.setString(4, studentObj.getPhone());
            int rowAffected = pst.executeUpdate();
            con.close();
            if(rowAffected>=1){
                return "Data Updated";
            }else{
                return "Data Not Updated";
            }
        }catch(Exception ex){
            ex.printStackTrace();
            return "Server error";
        }
    }
    public String deleteStudent(Student studentObj){
        try{
            Connection con= DriverManager.getConnection(url, user, password);
            String sql = "delete from studenttable where student_id=?";
            PreparedStatement pst =con.prepareStatement(sql);
            pst.setInt(1,studentObj.getId());
            
            int rowsAffected = pst.executeUpdate();
            con.close();
            if(rowsAffected > 0 ) {
                return "product delete successfully";
            }
            else {
                return "Product not deleted";
            }
        }catch(Exception ex){
            ex.printStackTrace();
            return "Server error";
        }
    }
    
    public List<Student> allStudents(){
             try{
              Connection con = DriverManager.getConnection(url, user, password);
              String sql="select * from studenttable";
              PreparedStatement pst = con.prepareStatement(sql);
              ResultSet rs = pst.executeQuery();
              List<Student> students = new ArrayList<>();
              while(rs.next()){
                  
                  Student studentObj = new Student();
                  studentObj.setName(rs.getString("student_name"));
                  studentObj.setId(rs.getInt("student_id"));
                  studentObj.setFaculty(rs.getString("faculty"));
                  studentObj.setDepartment(rs.getString("department"));
                  studentObj.setPhone(rs.getString("phone"));
                  students.add(studentObj);
              }
              con.close();
              return students;
          }catch(Exception ex){
              ex.printStackTrace();
          }
          return null;
    }
    public Student searchStudent(Student studentObj){
          try{
            Connection con = DriverManager.getConnection(url, user, password);
            String sql="select * from studenttable where student_id=?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setInt(1, studentObj.getId());
            ResultSet rs = pst.executeQuery();
            Student theStudent = new Student();

            while(rs.next()){
                theStudent.setName(rs.getString("student_name"));
                theStudent.setId(rs.getInt("student_id"));
                theStudent.setFaculty(rs.getString("faculty"));
                theStudent.setDepartment(rs.getString("department"));
                theStudent.setPhone(rs.getString("phone"));
            }
            con.close();
            return theStudent;
        }catch(Exception ex){
            ex.printStackTrace();
        }
        return null;
    }

    
}
