/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import dao.*;
import model.*;
/**
 *
 * @author Mwamba
 */
public class StudentView {
    public static void main(String[] args) {
        boolean condition = true;
        Integer id;
        String name;
        String faculty;
        String department;
        String phone;
        Student stud = new Student();
        StudentDao dao = new StudentDao();
        String answer;
        String feedback;
        while(condition){
            System.out.println("Stock Managment System");
            System.out.println("1. Create A Student");
            System.out.println("2. Update A Student");
            System.out.println("3. Delete A Student");
            System.out.println("4. Retrieve All Students");
            System.out.println("5. Search Student by id");
            System.out.println("0. Exit");
            System.out.println("------------");
            System.out.print("Choose: ");
            Scanner sc= new Scanner(System.in);
            int a=sc.nextInt();
            switch(a){
                case 1:
                    System.out.print("Enter Student ID  : ");
                    id = sc.nextInt();
                    System.out.print("Enter Student Name: ");
                    name = sc.next();
                    System.out.print("Enter Faculty Name : ");
                    faculty = sc.next();
                    System.out.print("Enter Department Nmae :");
                    department=sc.next();
                    System.out.print("Enter Phone Number :");
                    phone=sc.next();
                    
                    stud = new Student();
                    stud.setId(id);
                    stud.setName(name);
                    stud.setFaculty(faculty);
                    stud.setDepartment(department);
                    stud.setPhone(phone);
                    
                    dao = new StudentDao();
                    feedback = dao.registerStudent(stud);
                    System.out.println(feedback);
                    break;
                case 2:
                    System.out.print("Enter Student ID  : ");
                    id = sc.nextInt();
                    System.out.print("Enter Student Name: ");
                    name = sc.next();
                    System.out.print("Enter Faculty Name : ");
                    faculty = sc.next();
                    System.out.print("Enter Department Nmae :");
                    department=sc.next();
                    System.out.print("Enter Phone Number :");
                    phone=sc.next();
                    
                    stud = new Student();
                    stud.setId(id);
                    stud.setName(name);
                    stud.setFaculty(faculty);
                    stud.setDepartment(department);
                    stud.setPhone(phone);
                    
                    dao = new StudentDao();
                    feedback=dao.updateStudent(stud);
                    System.out.println(feedback);
                    System.out.println("Enter Yes to continue");
                    answer = sc.next();
                    if(answer.equalsIgnoreCase("yes")){
                        condition = true;
                    }else{
                        System.out.println("Thank you for using the system");
                        condition=false;
                    }
                    break;
                case 3:
                    System.out.print("Enter Student ID: ");
                    id = sc.nextInt();
                    stud = new Student();
                    stud.setId(id);
                    dao = new StudentDao();
                    feedback = dao.deleteStudent(stud);
                    System.out.println(feedback);
                    System.out.println("Enter Yes to continue");
                    answer = sc.next();
                    if(answer.equalsIgnoreCase("yes")){
                        condition = true;
                    }else{
                        System.out.println("Thank you for using the system");
                        condition=false;
                    }
                    break;
                case 4:
                    dao = new StudentDao();
                    List<Student> productList = dao.allStudents();
                    Iterator iterator = productList.iterator();
                    int counter =0;
                    if(productList!= null){

                          for(Student theStudent : productList){
                              counter ++;
                              System.out.println("Student "+counter);
                              System.out.println("----------");
                              System.out.println("Student ID   : "+theStudent.getId());
                              System.out.println("Student Name : "+theStudent.getName());
                              System.out.println("Student faculty: "+theStudent.getFaculty());
                              System.out.println("Student department: "+theStudent.getDepartment());
                              System.out.println("Student phone number: "+theStudent.getPhone());
                          }
                    }else{
                        System.out.println("No Data");
                    }
                    break;
                case 5:
                    System.out.println("Enter Student ID");
                    id = sc.nextInt();
                    stud = new Student();
                    stud.setId(id);
                    dao = new StudentDao();
                    Student theStudent = dao.searchStudent(stud);
                    if(theStudent!= null){
                        System.out.println("Student ");
                        System.out.println("----------");
                        System.out.println("Student ID   : "+theStudent.getId());
                        System.out.println("Student Name : "+theStudent.getName());
                        System.out.println("Student Faculty: "+theStudent.getFaculty());
                        System.out.println("Student Department: "+theStudent.getDepartment());
                        System.out.println("Student Phone: "+theStudent.getPhone());
                    }else{
                        System.out.println("Not Found");
                    }
                    break;

                case 0:
                    System.out.println("Thank you for using the system");
                    System.exit(0);
                    break;
                default:
             
            }
        }
    }
}
